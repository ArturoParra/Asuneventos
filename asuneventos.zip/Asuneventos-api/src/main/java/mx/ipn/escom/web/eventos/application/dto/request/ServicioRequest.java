package mx.ipn.escom.web.eventos.application.dto.request;

import jakarta.validation.constraints.NotBlank;

public class ServicioRequest {

    @NotBlank
    private String nombre;

    private String descripcion;

    public ServicioRequest() {}

    public ServicioRequest(String nombre, String descripcion) {
        this.nombre = nombre;
        this.descripcion = descripcion;
    }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
}
